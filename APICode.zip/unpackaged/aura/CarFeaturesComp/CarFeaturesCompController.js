({
    saveData : function(component, event, helper) {
        var cardetail=component.get("v.car");

        var action=component.get("c.carfeaturemethod");

        action.setParams({carData:cardetail});

        action.setCallback(this,function(response){
            console.log('data saved');
        });

        $A.enqueueAction(action);
    }
})