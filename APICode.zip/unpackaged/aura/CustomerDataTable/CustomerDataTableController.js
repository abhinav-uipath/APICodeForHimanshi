({
    myAction : function(component, event, helper) {
        component.set('v.customercolumn',[
            {label:'Customer First Name',fieldName:'Name',type:'text'},
            {label:'Customer Last Name',fieldName:'Customer_Last_Name__c',type:'text'},
            {label:'Customer Email ID',fieldName:'Customer_Mail_ID__c',type:'email'},
            {label:'Gender',fieldName:'Gender__c',type:'Pickist'},
            {label:'Phone',fieldName:'Mobile_Number__c',type:'phone'},
            {label:'Aadhar Number',fieldName:'Aadhar_Number__c',type:'text'},            
        ]);

       helper.getData(component);
    }
})