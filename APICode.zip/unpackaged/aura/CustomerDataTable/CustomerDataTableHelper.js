({
    getData : function(component) {
        var action= component.get('c.getCustomerlist');

        action.setCallback(this,function(response){

           var responsevalue= response.getReturnValue();
                component.set('v.customerlist',responsevalue);
 
        });
        $A.enqueueAction(action);
        
          }
})