({
getData : function(component) {
var action= component.get('c.getCarFeaturesList');
action.setCallback(this,function(response){
var responsevalue= response.getReturnValue();
component.set('v.CarList',responsevalue);

    console.log('Data Fetch');
    
});
$A.enqueueAction(action);




}
})