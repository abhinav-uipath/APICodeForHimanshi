({
    myAction : function(component, event, helper) {
        component.set('v.carcolumn',[
            {label:'CarName',fieldName:'Name',type:'Text'},
         //  {label:'Car Description',fieldName:'CarDescription__c',type:'Long Text Area'},
              {label:'Mileage',fieldName:'Mileage__c',type:'Text'},
          //  {label:'Dual AirBags Detail',fieldName:'Dual_AirBags__c',type:'Pickist'},
          //  {label:'Fuel Type Detail',fieldName:'Fuel_Type__c',type:'Pickist'},
           // {label:'ABS with EBD Detail',fieldName:'ABS_with_EBD__c',type:'Pickist'},
           // {label:'Auto Gear Detail',fieldName:'Auto_Gear__c',type:'Pickist'}
         
        ]);

       helper.getData(component);
    }
})