({
 BMICalculate : function(component, event, helper) {
        var input1=component.get('v.Weight');
        var input2=component.get('v.Height');
        var BMIValue=(parseFloat(input1)/(parseFloat(input2)*parseFloat(input2)));
        component.set("v.BMIValue",BMIValue);
 }
})