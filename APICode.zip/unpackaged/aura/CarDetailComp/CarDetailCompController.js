({
    myAction : function(component, event, helper) {
        var action=component.get("c.cardetailmethod");

        action.setCallback(this,function(response){
            var result=response.getReturnValue();
            component.set("v.CarDetailData",result);
        });

        $A.enqueueAction(action);
    }
})