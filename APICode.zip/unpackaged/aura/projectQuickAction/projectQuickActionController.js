({
    fetchProjects: function(component, event, helper) {
        var action = component.get("c.fetchAndSaveProjects");
        action.setParams({ contactId: component.get("v.contactId") });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.message", response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors && errors.length > 0) {
                    component.set("v.message", "Error: " + errors[0].message);
                } else {
                    component.set("v.message", "Unknown error occurred.");
                }
            }
        });
        
        $A.enqueueAction(action);
    }
})