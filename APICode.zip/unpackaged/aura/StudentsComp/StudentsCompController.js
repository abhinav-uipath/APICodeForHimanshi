({
    saveData : function(component, event, helper) {
        var condetail=component.get("v.stud");

        var action=component.get("c.studentmethod");

        action.setParams({conData:condetail});

        action.setCallback(this,function(response){
            console.log('data saved');
        });

        $A.enqueueAction(action);
    }
})