({
    back : function(component, event, helper) {
     var currenttab= component.get("v.selectedtabid");
        if(currenttab == '2'){
            component.set("v.selectedtabid",'1');
        }
         if(currenttab == '3'){
            component.set("v.selectedtabid",'2');
        }
    },
    next : function(component, event, helper) {
        var currenttab= component.get("v.selectedtabid");
        if(currenttab == '1'){
            component.set("v.selectedtabid",'2');
        }
         if(currenttab == '2'){
            component.set("v.selectedtabid",'3');
        }
    }
})